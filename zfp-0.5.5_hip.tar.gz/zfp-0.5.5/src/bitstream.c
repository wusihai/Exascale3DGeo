#include "bitstream.h"
#include "inline/bitstream.c"

export_ const size_t stream_word_bits = wsize;
