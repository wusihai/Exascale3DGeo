/* minimal code example showing how to call the zfp (de)compressor */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "zfp.h"

#include <ios>
#include <iostream>
using namespace std;
#include <thread>
#include"fstream"
#include <chrono>
#include <string.h>

#ifdef WIN32
#include <windows.h>  
#include <psapi.h>  
//#include <tlhelp32.h>
#include <direct.h>
#include <process.h>
#else
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sys/time.h>
#include <unistd.h>
#endif

#include <unistd.h>
#include <ios>
#include <string>

#include <unistd.h>
#include <sys/time.h>

#define VMRSS_LINE 18
#define VMSIZE_LINE 13
#define PROCESS_ITEM 14

// get current process pid
inline int GetCurrentPid()
{
	return getpid();
}
#define VMRSS_LINE 18
#define PROCESS_ITEM 14

// get specific process physical memeory occupation size by pid (MB)
inline float GetMemoryUsage(int pid)
{
#ifdef WIN32
	uint64_t mem = 0, vmem = 0;
	PROCESS_MEMORY_COUNTERS pmc;

	// get process hanlde by pid
	HANDLE process = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	if (GetProcessMemoryInfo(process, &pmc, sizeof(pmc)))
	{
		mem = pmc.WorkingSetSize;
		vmem = pmc.PagefileUsage;
	}
	CloseHandle(process);

	// use GetCurrentProcess() can get current process and no need to close handle

	// convert mem from B to MB
	return mem / 1024.0 / 1024.0;

#else
	char file_name[64] = { 0 };
	FILE* fd;
	char line_buff[512] = { 0 };
	sprintf(file_name, "/proc/%d/status", pid);

	fd = fopen(file_name, "r");
	if (nullptr == fd)
		return 0;

	char name[64];
	int vmrss = 0;
	for (int i = 0; i < VMRSS_LINE - 1; i++)
		fgets(line_buff, sizeof(line_buff), fd);

	fgets(line_buff, sizeof(line_buff), fd);
	sscanf(line_buff, "%s %d", name, &vmrss);
	fclose(fd);

	// cnvert VmRSS from KB to MB
	return vmrss / 1024.0;
#endif
}

/* compress or decompress array */
	static int
compress(double* array, int nx, int ny, int nz, double tolerance, int decompress)
{
	int status = 0;    /* return value: 0 = success */
	zfp_type type;     /* array scalar type */
	zfp_field* field;  /* array meta data */
	zfp_stream* zfp;   /* compressed stream */
	void* buffer;      /* storage for compressed stream */
	size_t bufsize;    /* byte size of compressed buffer */
	bitstream* stream; /* bit stream to write to or read from */
	size_t zfpsize;    /* byte size of compressed stream */

	/* allocate meta data for the 3D array a[nz][ny][nx] */
	type = zfp_type_double;
	field = zfp_field_3d(array, type, nx, ny, nz);

	/* allocate meta data for a compressed stream */
	zfp = zfp_stream_open(NULL);

	/* set compression mode and parameters via one of three functions */
	/*  zfp_stream_set_rate(zfp, rate, type, 3, 0); */
	/*  zfp_stream_set_precision(zfp, precision); */
	zfp_stream_set_accuracy(zfp, tolerance);

	/* allocate buffer for compressed data */
	bufsize = zfp_stream_maximum_size(zfp, field);
	buffer = malloc(bufsize);

	/* associate bit stream with allocated buffer */
	stream = stream_open(buffer, bufsize);
	zfp_stream_set_bit_stream(zfp, stream);
	zfp_stream_rewind(zfp);

	/* compress or decompress entire array */
	//if (decompress) {
	//	/* read compressed stream and decompress array */
	//	zfpsize = fread(buffer, 1, bufsize, stdin);
	//	if (!zfp_decompress(zfp, field)) {
	//		fprintf(stderr, "decompression failed\n");
	//		status = 1;
	//	}
	//}
	//else {
	/* compress array and output compressed stream */
	zfpsize = zfp_compress(zfp, field);
	// if (!zfpsize) {
	//   fprintf(stderr, "compression failed\n");
	//   status = 1;
	// }
	// else
	//   fwrite(buffer, 1, zfpsize, stdout);
	//}

	/* clean up */
	zfp_field_free(field);
	zfp_stream_close(zfp);
	stream_close(stream);
	free(buffer);
	//free(array);

	//return status;
}

int main(int argc, char* argv[])
{

	/* use -d to decompress rather than compress data */
	int decompress = (argc == 2 && !strcmp(argv[1], "-d"));
	/* allocate 100x100x100 array of doubles */
	int nx =300;
	int ny =300;
	int nz =300;
	double* array = (double*)malloc(nx * ny * nz * sizeof(double));

	//	if (!decompress) {
	/* initialize array to be compressed */
	int i, j, k;
	for (k = 0; k < nz; k++)
		for (j = 0; j < ny; j++)
			for (i = 0; i < nx; i++) {
				double x = 2.0 * i / rand();
				double y = 2.0 * j / rand();
				double z = 2.0 * k / rand();
				array[i + nx * (j + ny * k)] = exp(-(x * x + y * y + z * z));
			}
	//	}
	for(int l=0;l<200000;l++){
		int current_pid = GetCurrentPid(); // or you can set a outside program pid
		float memory_usage = GetMemoryUsage(current_pid);
		printf("mem=%f\n",memory_usage);
		fflush(stdout);
		/* compress or decompress array */
		compress(array, nx, ny, nz, 1e-5, decompress);
	}
	free(array);
	//}
	}
